# 伊雷娜 — AI 虚拟人

基于 Live2D + DeepSeek + 阿里云百炼的 AI 虚拟人聊天应用。《魔女之旅》伊雷娜角色扮演，支持实时对话、语音合成、语音识别和丰富表情动作。

---

## 功能特性

- **Live2D 模型渲染**：Cubism 4 引擎 + PIXI.js 实时渲染
- **AI 对话**：DeepSeek V4 Flash，角色扮演系统提示词
- **语音合成**：百炼 qwen3-tts-flash（Chelsie 千雪音色）
- **语音识别**：百炼 Qwen3-ASR-Flash，按下说话松开识别
- **动作系统**：20+ 种表情动作（开心/害羞/惊讶/挥手/点头/伸懒腰/鼓掌/打哈欠等）
- **互动系统**：鼠标拖拽、点击反应、视线追踪、自动眨眼
- **对话记忆**：localStorage 持久化，刷新保留历史
- **响应式设计**：适配手机端布局

---

## 技术栈

| 模块 | 技术 |
|------|------|
| 前端 | HTML5 + CSS3 + PIXI.js |
| Live2D | Cubism 4 Core + pixi-live2d-display |
| AI 对话 | DeepSeek API (deepseek-v4-flash) |
| 语音合成 | 阿里云百炼 qwen3-tts-flash |
| 语音识别 | 阿里云百炼 Qwen3-ASR-Flash |
| 后端 | Node.js + Express |

---

## 快速开始

### 1. 安装依赖

```bash
npm install
```

### 2. 配置 API Key

编辑 `index.html` 第 189-191 行：

```javascript
const DEEPSEEK_API_KEY = "配置你的DeepSeek_API_Key";     // 改为你的 Key
const BAILIAN_API_KEY = "配置你的阿里云百炼_API_Key";      // 改为你的 Key
```

编辑 `server.js` 第 9 行：

```javascript
const BAILIAN_API_KEY = process.env.BAILIAN_API_KEY || '配置你的阿里云百炼_API_Key';
```

### 3. 启动

```bash
node server.js
```

浏览器打开 `http://localhost:3001`

---

## API Key 获取方式

### DeepSeek API Key

1. 访问 https://platform.deepseek.com/
2. 注册/登录 → API Keys → 创建 Key
3. 复制填入 `index.html` 的 `DEEPSEEK_API_KEY`

### 阿里云百炼 API Key

1. 访问 https://bailian.console.aliyun.com/
2. 开通「大模型服务平台百炼」服务
3. 控制台 → 模型广场 → 开通 `qwen3-tts-flash`（语音合成）和 `qwen3-asr-flash`（语音识别）
4. 右上角头像 → API-KEY 管理 → 创建新的 API Key
5. 复制填入 `index.html` 和 `server.js` 的 `BAILIAN_API_KEY`

---

## 部署到服务器

### 宝塔面板

1. 软件商店 → Node.js 版本管理器 → 安装 v18.x 或 v20.x
2. 上传项目到 `/www/wwwroot/xuniren/`
3. 终端执行：

```bash
cd /www/wwwroot/xuniren
npm install
nohup node server.js > /dev/null 2>&1 &
```

4. 安全 → 放行端口 `3001`

### 绑定域名（Nginx 反代）

```nginx
server {
    listen 80;
    server_name 你的域名;

    location / {
        proxy_pass http://127.0.0.1:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

### Docker 部署

```bash
docker run --name xuniren -p 3001:3001 -v $(pwd):/app -w /app -d node:20 node server.js
```

---

## 项目结构

```
xuniren/
├── index.html          # 前端页面（Live2D + 聊天 + 动作系统）
├── server.js           # 后端服务（TTS + ASR 代理）
├── package.json        # 依赖配置
├── model/              # Live2D 模型文件
├── avatar.png          # 回退头像
└── README.md
```

---

## 自定义配置

### 修改 AI 角色

编辑 `index.html` 中的 `SYSTEM_PROMPT` 变量，修改角色设定和回答风格。

### 修改 TTS 音色

`server.js` 第 27 行的 `voice` 参数，可选音色参考：[Qwen-TTS 音色列表](https://help.aliyun.com/zh/model-studio/qwen-tts-voice-list)

### 修改 AI 模型

`index.html` 第 190 行 `DEEPSEEK_MODEL`，可选：`deepseek-v4-flash`（推荐）、`deepseek-v4-pro`

---

## 环境变量（可选）

生产环境建议使用环境变量管理密钥，避免硬编码泄露：

```bash
export DEEPSEEK_API_KEY="你的Key"
export BAILIAN_API_KEY="你的Key"
```

---

## 许可证

MIT License
