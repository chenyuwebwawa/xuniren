﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿﻿const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));

// ========== 配置（支持环境变量，开发环境有默认值）==========
const BAILIAN_API_KEY = process.env.BAILIAN_API_KEY || '配置你的阿里云百炼_API_Key';
const BAILIAN_BASE = process.env.BAILIAN_BASE || 'https://dashscope.aliyuncs.com';

// ========== TTS：qwen3-tts-flash ==========
app.post('/tts', async (req, res) => {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: '缺少text参数' });

    try {
        const response = await fetch(`${BAILIAN_BASE}/api/v1/services/aigc/multimodal-generation/generation`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${BAILIAN_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'qwen3-tts-flash',
                input: {
                    text: text,
                    voice: 'Chelsie',
                    language_type: 'Chinese'
                }
            })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message || data.error?.message || response.status);

        const audioUrl = data.output?.audio?.url;
        if (audioUrl) {
            const audioResp = await fetch(audioUrl);
            const audioBuffer = await audioResp.arrayBuffer();
            res.setHeader('Content-Type', 'audio/mpeg');
            res.send(Buffer.from(audioBuffer));
        } else {
            console.error('TTS返回数据:', JSON.stringify(data).slice(0, 500));
            res.status(500).json({ error: 'TTS响应中未找到音频URL' });
        }
    } catch (error) {
        console.error('TTS生成失败:', error);
        res.status(500).json({ error: 'TTS生成失败', details: error.message });
    }
});

// ========== ASR：Qwen3-ASR-Flash（OpenAI 兼容）==========
app.post('/asr', async (req, res) => {
    const { audio, mimeType } = req.body;
    if (!audio) return res.status(400).json({ error: '缺少audio参数' });

    try {
        const dataUrl = `data:${mimeType || 'audio/webm'};base64,${audio}`;

        const response = await fetch(`${BAILIAN_BASE}/compatible-mode/v1/chat/completions`, {
            method: 'POST',
            headers: {
                'Authorization': `Bearer ${BAILIAN_API_KEY}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                model: 'qwen3-asr-flash',
                messages: [
                    {
                        role: 'user',
                        content: [
                            {
                                type: 'input_audio',
                                input_audio: {
                                    data: dataUrl
                                }
                            }
                        ]
                    }
                ],
                asr_options: {
                    language: 'zh'
                }
            })
        });

        const data = await response.json();
        if (!response.ok) throw new Error(data.message || data.error?.message || response.status);

        const text = data.choices?.[0]?.message?.content || '';
        res.json({ text: text.trim() });
    } catch (error) {
        console.error('ASR识别失败:', error);
        res.status(500).json({ error: 'ASR识别失败', details: error.message });
    }
});

// 静态文件服务（前端页面）
app.use(express.static(__dirname));

const PORT = 3001;
app.listen(PORT, () => {
    console.log('========================================');
    console.log(`  AI虚拟人 · 伊雷娜`);
    console.log(`  服务运行在 http://localhost:${PORT}`);
    console.log(`  AI模型: DeepSeek V4 Flash`);
    console.log(`  TTS: 百炼 qwen3-tts-flash (Chelsie/千雪)`);
    console.log(`  ASR: 百炼 Qwen3-ASR-Flash`);
    console.log('========================================');
});
